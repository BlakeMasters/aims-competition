"""Text-factor plus sparse-IRT stack runtime."""

from __future__ import annotations

import importlib.util
import json
import math
from pathlib import Path


ARTIFACT_PATH = Path(__file__).resolve().parent / "artifacts" / "text_factor_stack.json"
CONFIG = {
    "clean_weight": 0.20,
    "sparse_weight": 0.45,
    "text_weight": 0.35,
    "center": 0.55,
    "temperature": 1.12,
}
CLEAN = None
SPARSE = None
TEXT = None


def predict(input: dict, labeled: list[dict] | None = None) -> float:
    try:
        _load_models()
        parts = []
        weights = []
        clean_weight = float(CONFIG.get("clean_weight", 0.20))
        sparse_weight = float(CONFIG.get("sparse_weight", 0.45))
        text_weight = float(CONFIG.get("text_weight", 0.35))
        if clean_weight > 0.0:
            parts.append(_logit(_clip(CLEAN.predict(dict(input), labeled=labeled))))
            weights.append(clean_weight)
        if sparse_weight > 0.0:
            parts.append(_logit(_clip(SPARSE.predict(dict(input), labeled=labeled))))
            weights.append(sparse_weight)
        if text_weight > 0.0:
            parts.append(_logit(_clip(TEXT.predict(dict(input), labeled=labeled))))
            weights.append(text_weight)
        if not parts:
            return 0.55
        total = max(sum(weights), 1e-9)
        logit = sum(w * p for w, p in zip(weights, parts)) / total
        center = _clip(CONFIG.get("center", 0.55))
        temperature = max(float(CONFIG.get("temperature", 1.0)), 0.1)
        centered = _logit(center) + (logit - _logit(center)) / temperature
        return _clip(_sigmoid(centered))
    except Exception:
        return 0.55


def _load_models() -> None:
    global CLEAN, SPARSE, TEXT
    if CLEAN is not None and SPARSE is not None and TEXT is not None:
        return
    root = Path(__file__).resolve().parent
    CLEAN = _load_module(root / "clean_model.py", "text_factor_stack_clean_model")
    SPARSE = _load_module(root / "sparse_model.py", "text_factor_stack_sparse_model")
    TEXT = _load_module(root / "text_model.py", "text_factor_stack_text_model")


def _load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"could not load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _load_config() -> None:
    global CONFIG
    if not ARTIFACT_PATH.exists():
        return
    try:
        payload = json.loads(ARTIFACT_PATH.read_text(encoding="utf-8"))
        CONFIG.update(payload.get("stack", {}) or {})
    except Exception:
        pass


def _clip(value) -> float:
    try:
        p = float(value)
    except Exception:
        return 0.55
    if not math.isfinite(p):
        return 0.55
    return min(max(p, 1e-4), 1.0 - 1e-4)


def _logit(value: float) -> float:
    p = _clip(value)
    return math.log(p / (1.0 - p))


def _sigmoid(value: float) -> float:
    value = max(min(float(value), 30.0), -30.0)
    return 1.0 / (1.0 + math.exp(-value))


_load_config()
