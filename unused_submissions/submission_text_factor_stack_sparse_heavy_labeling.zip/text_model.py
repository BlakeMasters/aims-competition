"""Text-predicted low-rank response-factor runtime."""

from __future__ import annotations

import collections
import hashlib
import json
import math
import re
from pathlib import Path


ARTIFACT_PATH = Path(__file__).resolve().parent / "artifacts" / "text_factor.json"
TOKEN_RE = re.compile(r"[A-Za-z0-9_./:+-]{2,}")
ALIAS_RE = re.compile(r"[^a-z0-9]+")
OPTION_RE = re.compile(r"(?:^|\n|\s)(?:\(?[A-Ha-h]\)?[\).:]|option\s+[A-Ha-h]\b)")
NUMBER_RE = re.compile(r"[-+]?\d+(?:\.\d+)?")
CODE_RE = re.compile(r"\b(def|class|import|return|function|public|private|const|let|var|python|java|javascript|sql|bash|stack trace|exception)\b|```|[{};]")
MATH_RE = re.compile(r"\b(prove|theorem|equation|integral|derivative|matrix|geometry|probability|calculate|solve|integer|decimal)\b|[=+\-*/^<>]")
MEDICAL_RE = re.compile(r"\b(patient|diagnosis|clinical|treatment|symptom|disease|drug|dose|medical|doctor|hospital|therapy)\b")
SAFETY_RE = re.compile(r"\b(safety|harm|attack|exploit|malware|toxic|bias|jailbreak|policy|privacy|secure|risk)\b")
TOOL_RE = re.compile(r"\b(api|tool|function call|json|browser|android|web|terminal|shell|agent|environment)\b")
VISUAL_RE = re.compile(r"\b(image|diagram|figure|chart|graph|picture|visual|screenshot|bounding box)\b")

EPS = 1e-4
GLOBAL_MEAN = 0.5
HASH_DIM = 4096
COMPONENTS = 16
SUBJECT_ALIAS_STATS = {}
SUBJECT_FACTORS = {}
TEXT_FACTOR_INTERCEPT = []
TEXT_FACTOR_COEFFICIENTS = []
TEXT_BIAS_INTERCEPT = 0.0
TEXT_BIAS_COEFFICIENTS = []
DOMAIN_FAMILY_STATS = {}
DOMAIN_SIGNATURE_STATS = {}
DOMAIN_SHAPE_STATS = {}
FORMULA = {
    "center": None,
    "subject_weight": 0.72,
    "domain_weight": 0.12,
    "text_weight": 0.18,
    "factor_weight": 0.80,
    "strength": 0.95,
    "temperature": 1.0,
}


def predict(input: dict, labeled: list[dict] | None = None) -> float:
    try:
        subject = str(input.get("subject_content", "") or "")
        item = str(input.get("item_content", "") or "")
        alias = _normalize_alias(_extract_subject_name(subject))
        center_raw = FORMULA.get("center")
        center = GLOBAL_MEAN if center_raw is None else _clip_probability(center_raw)
        subject_p = _lookup(SUBJECT_ALIAS_STATS, alias, GLOBAL_MEAN)
        domain_p = _domain_prior(item)
        text_bias = _predict_text_bias(item)
        item_vec = _predict_item_factors(item)
        subject_vec = SUBJECT_FACTORS.get(alias)
        factor_score = 0.0
        if subject_vec:
            limit = min(len(subject_vec), len(item_vec))
            for idx in range(limit):
                factor_score += float(subject_vec[idx]) * float(item_vec[idx])
        raw = center + float(FORMULA.get("strength", 1.0)) * (
            float(FORMULA.get("subject_weight", 0.0)) * (subject_p - center)
            + float(FORMULA.get("domain_weight", 0.0)) * (domain_p - center)
            + float(FORMULA.get("text_weight", 0.0)) * text_bias
            + float(FORMULA.get("factor_weight", 0.0)) * factor_score
        )
        p = _cool_probability(raw, center, float(FORMULA.get("temperature", 1.0)))
        p = _adjust_with_labeled(_clip_probability(p), alias, input, labeled, center)
        return _clip_probability(p)
    except Exception:
        return _clip_probability(GLOBAL_MEAN)


def _load_artifact() -> None:
    global EPS, GLOBAL_MEAN, HASH_DIM, COMPONENTS
    global SUBJECT_ALIAS_STATS, SUBJECT_FACTORS, TEXT_FACTOR_INTERCEPT, TEXT_FACTOR_COEFFICIENTS
    global TEXT_BIAS_INTERCEPT, TEXT_BIAS_COEFFICIENTS
    global DOMAIN_FAMILY_STATS, DOMAIN_SIGNATURE_STATS, DOMAIN_SHAPE_STATS, FORMULA
    if not ARTIFACT_PATH.exists():
        return
    with ARTIFACT_PATH.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    EPS = float(payload.get("eps", EPS))
    GLOBAL_MEAN = _clip_probability(payload.get("global_mean", GLOBAL_MEAN))
    HASH_DIM = int(payload.get("hash_dim", HASH_DIM))
    COMPONENTS = int(payload.get("components", COMPONENTS))
    SUBJECT_ALIAS_STATS = payload.get("subject_alias_stats", {}) or {}
    SUBJECT_FACTORS = payload.get("subject_factors", {}) or {}
    TEXT_FACTOR_INTERCEPT = [float(x) for x in payload.get("text_factor_intercept", [])]
    TEXT_FACTOR_COEFFICIENTS = payload.get("text_factor_coefficients", []) or []
    TEXT_BIAS_INTERCEPT = float(payload.get("text_bias_intercept", 0.0))
    TEXT_BIAS_COEFFICIENTS = [float(x) for x in payload.get("text_bias_coefficients", [])]
    DOMAIN_FAMILY_STATS = payload.get("domain_family_stats", {}) or {}
    DOMAIN_SIGNATURE_STATS = payload.get("domain_signature_stats", {}) or {}
    DOMAIN_SHAPE_STATS = payload.get("domain_shape_stats", {}) or {}
    FORMULA.update(payload.get("runtime_formula", {}) or {})


def _predict_item_factors(item: str) -> list[float]:
    features = _text_features(item)
    out = list(TEXT_FACTOR_INTERCEPT[:COMPONENTS])
    if len(out) < COMPONENTS:
        out.extend([0.0] * (COMPONENTS - len(out)))
    for hashed_idx, value in features.items():
        for component in range(min(COMPONENTS, len(TEXT_FACTOR_COEFFICIENTS))):
            row = TEXT_FACTOR_COEFFICIENTS[component]
            if hashed_idx < len(row):
                out[component] += float(row[hashed_idx]) * value
    return out


def _predict_text_bias(item: str) -> float:
    features = _text_features(item)
    score = float(TEXT_BIAS_INTERCEPT)
    for hashed_idx, value in features.items():
        if hashed_idx < len(TEXT_BIAS_COEFFICIENTS):
            score += float(TEXT_BIAS_COEFFICIENTS[hashed_idx]) * value
    return max(min(score, 0.45), -0.45)


def _text_features(text: str) -> dict[int, float]:
    tokens = [m.group(0).lower() for m in TOKEN_RE.finditer(str(text or ""))][:220]
    raw = collections.Counter()
    for token in tokens:
        raw[_stable_hash("tok:" + token, HASH_DIM)] += 1
    for left, right in zip(tokens, tokens[1:]):
        raw[_stable_hash("bi:" + left + "_" + right, HASH_DIM)] += 1
    keys = _domain_keys(str(text or ""))
    for key, value in keys.items():
        raw[_stable_hash("dom:" + key + "=" + str(value), HASH_DIM)] += 3
    if not raw:
        raw[_stable_hash("empty", HASH_DIM)] = 1
    norm = math.sqrt(sum(float(value) * float(value) for value in raw.values()))
    return {int(idx): float(value) / norm for idx, value in raw.items()}


def _domain_prior(item: str) -> float:
    keys = _domain_keys(item)
    shape = _lookup(DOMAIN_SHAPE_STATS, keys["shape"], GLOBAL_MEAN)
    family = _lookup(DOMAIN_FAMILY_STATS, keys["family"], shape)
    signature = _lookup(DOMAIN_SIGNATURE_STATS, keys["signature"], family)
    return _clip_probability(0.50 * signature + 0.30 * family + 0.20 * shape)


def _domain_keys(item: str) -> dict[str, str]:
    text = str(item or "")
    lower = text.lower()
    tokens = TOKEN_RE.findall(text)
    option_count = len(OPTION_RE.findall(text))
    number_count = len(NUMBER_RE.findall(text))
    flags = []
    if CODE_RE.search(lower):
        flags.append("code")
    if MATH_RE.search(lower):
        flags.append("math")
    if MEDICAL_RE.search(lower):
        flags.append("medical")
    if SAFETY_RE.search(lower):
        flags.append("safety")
    if TOOL_RE.search(lower):
        flags.append("tool")
    if VISUAL_RE.search(lower):
        flags.append("visual")
    if option_count >= 4:
        flags.append("multi_choice")
    if not flags:
        flags.append("generic")
    if "code" in flags:
        family = "code"
    elif "tool" in flags:
        family = "tool"
    elif "medical" in flags:
        family = "medical"
    elif "safety" in flags:
        family = "safety"
    elif "visual" in flags and "math" in flags:
        family = "visual_math"
    elif "visual" in flags:
        family = "visual"
    elif "math" in flags:
        family = "math"
    elif "multi_choice" in flags:
        family = "multi_choice"
    else:
        family = "generic"
    if len(tokens) < 40:
        length = "short"
    elif len(tokens) < 120:
        length = "medium"
    elif len(tokens) < 320:
        length = "long"
    else:
        length = "very_long"
    options = "opt4" if option_count >= 4 else ("opt1to3" if option_count else "opt0")
    numbers = "num_many" if number_count >= 6 else ("num_some" if number_count else "num0")
    flag_key = "+".join(sorted(flags))
    return {
        "family": family,
        "shape": f"{length}|{options}|{numbers}",
        "signature": f"{family}|{length}|{options}|{numbers}|{flag_key}",
    }


def _adjust_with_labeled(p: float, alias: str, input_row: dict, labeled: list[dict] | None, center: float) -> float:
    if not labeled:
        return p
    all_values = []
    same_subject = []
    benchmark = _normalize_text(input_row.get("benchmark", ""))
    same_benchmark = []
    for row in labeled:
        try:
            visible = row.get("input", row)
            label = float(row.get("label", row.get("response", row.get("correct"))))
            if not math.isfinite(label):
                continue
            value = 1.0 if label >= 0.5 else 0.0
            all_values.append(value)
            if _normalize_alias(_extract_subject_name(str(visible.get("subject_content", "") or ""))) == alias:
                same_subject.append(value)
            if _normalize_text(visible.get("benchmark", "")) == benchmark:
                same_benchmark.append(value)
        except Exception:
            continue
    adjusted = p
    adjusted = _label_shift(adjusted, all_values, center, 0.06, 22.0)
    adjusted = _label_shift(adjusted, same_benchmark, center, 0.12, 8.0)
    adjusted = _label_shift(adjusted, same_subject, center, 0.10, 5.0)
    return adjusted


def _label_shift(p: float, values: list[float], center: float, max_weight: float, shrink: float) -> float:
    if not values:
        return p
    observed = sum(values) / len(values)
    weight = max_weight * (len(values) / (len(values) + shrink))
    return p + weight * (observed - center)


def _cool_probability(value: float, center: float, temperature: float) -> float:
    temperature = max(float(temperature), 0.1)
    return _sigmoid(_safe_logit(center) + (_safe_logit(value) - _safe_logit(center)) / temperature)


def _lookup(stats: dict, key: object, fallback: float) -> float:
    value = stats.get(str(key))
    if value is None:
        return float(fallback)
    try:
        if isinstance(value, list):
            return float(value[0])
        return float(value.get("mean", fallback))
    except Exception:
        return float(fallback)


def _extract_subject_name(subject_content: str) -> str:
    for line in str(subject_content or "").splitlines():
        if line.lower().startswith("name:"):
            return line.split(":", 1)[1]
    return ""


def _normalize_text(text: object) -> str:
    return " ".join(str(text or "").lower().strip().split())


def _normalize_alias(text: object) -> str:
    value = str(text or "").lower()
    value = value.replace("instruct", "inst")
    value = value.replace("chat", "")
    return ALIAS_RE.sub("", value)


def _safe_logit(value: float) -> float:
    p = _clip_probability(value)
    return math.log(p / (1.0 - p))


def _sigmoid(value: float) -> float:
    value = max(min(float(value), 30.0), -30.0)
    return 1.0 / (1.0 + math.exp(-value))


def _clip_probability(value: object) -> float:
    try:
        p = float(value)
    except Exception:
        return float(GLOBAL_MEAN)
    if not math.isfinite(p):
        return float(GLOBAL_MEAN)
    return float(min(max(p, EPS), 1.0 - EPS))


def _stable_hash(text: str, modulo: int) -> int:
    digest = hashlib.blake2b(text.encode("utf-8", errors="ignore"), digest_size=8).digest()
    return int.from_bytes(digest, "little") % modulo


_load_artifact()
