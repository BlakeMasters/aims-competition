"""AUC-oriented adaptive-label acquisition for stacked submissions."""

from __future__ import annotations

import hashlib
import importlib
import math

try:
    import model
except Exception:  # pragma: no cover - hosted fallback path
    model = None


COMPONENT_NAMES = ("clean_model", "item_model", "rank_model", "irt_model", "sparse_model", "text_model")
COMPONENTS = None


def acquisition_function(input: dict) -> float:
    """Prioritize labels where the stacked rank signals disagree."""
    row = dict(input)
    try:
        components = _load_components()
        component_predictions = [
            p for p in (_safe_predict(component, row) for component in components) if p is not None
        ]
        final_prediction = _mean(component_predictions, 0.5)
        if len(component_predictions) < 2:
            fallback_prediction = _safe_predict(model, row)
            if fallback_prediction is not None:
                final_prediction = fallback_prediction

        uncertainty = final_prediction * (1.0 - final_prediction)
        disagreement = 0.0
        pair_gap = 0.0
        if len(component_predictions) >= 2:
            disagreement = max(component_predictions) - min(component_predictions)
            gaps = []
            for left in range(len(component_predictions)):
                for right in range(left + 1, len(component_predictions)):
                    gaps.append(abs(component_predictions[left] - component_predictions[right]))
            pair_gap = _mean(gaps, 0.0)

        benchmark = str(row.get("benchmark", "") or "")
        condition = str(row.get("condition", "") or "")
        subject = str(row.get("subject_content", "") or "")
        item = str(row.get("item_content", "") or "")
        novelty = _stable_unit(benchmark + "\n" + condition + "\n" + subject[:300])
        tie_break = _stable_unit(
            benchmark + "\n" + condition + "\n" + subject[:300] + "\n" + item[:1000]
        )

        score = (
            0.42 * pair_gap
            + 0.35 * uncertainty
            + 0.18 * disagreement
            + 0.04 * novelty
            + 1e-5 * tie_break
        )
        return float(score) if math.isfinite(score) else 0.0
    except Exception:
        return 0.0


def _load_components():
    global COMPONENTS
    if COMPONENTS is not None:
        return COMPONENTS
    loaded = []
    for name in COMPONENT_NAMES:
        try:
            loaded.append(importlib.import_module(name))
        except Exception:
            continue
    COMPONENTS = tuple(loaded)
    return COMPONENTS


def _safe_predict(module, row: dict) -> float | None:
    if module is None or not hasattr(module, "predict"):
        return None
    try:
        p = float(module.predict(dict(row), labeled=[]))
    except Exception:
        return None
    if not math.isfinite(p):
        return None
    return min(max(p, 1e-4), 1.0 - 1e-4)


def _mean(values, default: float) -> float:
    values = list(values)
    if not values:
        return default
    return float(sum(values) / len(values))


def _stable_unit(text: str) -> float:
    digest = hashlib.blake2b(str(text).encode("utf-8", errors="ignore"), digest_size=8).digest()
    return int.from_bytes(digest, "little") / float(2**64 - 1)
