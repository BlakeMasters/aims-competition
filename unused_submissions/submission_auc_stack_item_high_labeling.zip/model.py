"""AUC-first stack runtime."""

from __future__ import annotations

import importlib.util
import json
import math
from pathlib import Path


ARTIFACT_PATH = Path(__file__).resolve().parent / "artifacts" / "auc_stack.json"
CONFIG = {
    "clean_weight": 0.5,
    "item_weight": 0.35,
    "rank_weight": 0.15,
    "center": 0.55,
    "temperature": 1.12,
}
CLEAN = None
ITEM = None
RANK = None


def predict(input: dict, labeled: list[dict] | None = None) -> float:
    try:
        _load_models()
        clean = _clip(CLEAN.predict(dict(input), labeled=labeled))
        item = _clip(ITEM.predict(dict(input), labeled=labeled))
        rank = _clip(RANK.predict(dict(input), labeled=labeled))
        clean_weight = float(CONFIG.get("clean_weight", 0.5))
        item_weight = float(CONFIG.get("item_weight", 0.35))
        rank_weight = float(CONFIG.get("rank_weight", 0.15))
        total = max(clean_weight + item_weight + rank_weight, 1e-9)
        logit = (
            clean_weight * _logit(clean)
            + item_weight * _logit(item)
            + rank_weight * _logit(rank)
        ) / total
        center = _clip(CONFIG.get("center", 0.55))
        temperature = max(float(CONFIG.get("temperature", 1.0)), 0.1)
        centered = _logit(center) + (logit - _logit(center)) / temperature
        return _clip(_sigmoid(centered))
    except Exception:
        return 0.55


def _load_models() -> None:
    global CLEAN, ITEM, RANK
    if CLEAN is not None and ITEM is not None and RANK is not None:
        return
    root = Path(__file__).resolve().parent
    CLEAN = _load_module(root / "clean_model.py", "auc_stack_clean_model")
    ITEM = _load_module(root / "item_model.py", "auc_stack_item_model")
    RANK = _load_module(root / "rank_model.py", "auc_stack_rank_model")


def _load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"could not load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _load_config() -> None:
    global CONFIG
    if not ARTIFACT_PATH.exists():
        return
    try:
        payload = json.loads(ARTIFACT_PATH.read_text(encoding="utf-8"))
        CONFIG.update(payload.get("stack", {}) or {})
    except Exception:
        pass


def _clip(value) -> float:
    try:
        p = float(value)
    except Exception:
        return 0.55
    if not math.isfinite(p):
        return 0.55
    return min(max(p, 1e-4), 1.0 - 1e-4)


def _logit(value: float) -> float:
    p = _clip(value)
    return math.log(p / (1.0 - p))


def _sigmoid(value: float) -> float:
    value = max(min(float(value), 30.0), -30.0)
    return 1.0 / (1.0 + math.exp(-value))


_load_config()
