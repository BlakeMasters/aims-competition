"""Compact hybrid runtime for the predictive evaluation task."""

from __future__ import annotations

import hashlib
import json
import math
import re
from pathlib import Path


ARTIFACT_PATH = Path(__file__).resolve().parent / "artifacts" / "clean_hybrid.json"
TOKEN_RE = re.compile(r"[A-Za-z0-9_./:+-]{2,}")
ALIAS_RE = re.compile(r"[^a-z0-9]+")
OPTION_RE = re.compile(r"(?:^|\n|\s)(?:\(?[A-Ha-h]\)?[\).:]|option\s+[A-Ha-h]\b)")
NUMBER_RE = re.compile(r"[-+]?\d+(?:\.\d+)?")
CODE_RE = re.compile(r"\b(def|class|import|return|function|public|private|const|let|var|python|java|javascript|sql|bash|stack trace|exception)\b|```|[{};]")
MATH_RE = re.compile(r"\b(prove|theorem|equation|integral|derivative|matrix|geometry|probability|calculate|solve|integer|decimal)\b|[=+\-*/^<>]")
MEDICAL_RE = re.compile(r"\b(patient|diagnosis|clinical|treatment|symptom|disease|drug|dose|medical|doctor|hospital|therapy)\b")
SAFETY_RE = re.compile(r"\b(safety|harm|attack|exploit|malware|toxic|bias|jailbreak|policy|privacy|secure|risk)\b")
TOOL_RE = re.compile(r"\b(api|tool|function call|json|browser|android|web|terminal|shell|agent|environment)\b")
VISUAL_RE = re.compile(r"\b(image|diagram|figure|chart|graph|picture|visual|screenshot|bounding box)\b")

EPS = 1e-4
HASH_DIM = 32768
DENSE_DIM = 22
GLOBAL_MEAN = 0.5
SUBJECT_STATS: dict[str, dict[str, float]] = {}
SUBJECT_NAME_STATS: dict[str, dict[str, float]] = {}
SUBJECT_ALIAS_STATS: dict[str, dict[str, float]] = {}
SUBJECT_BENCHMARK_STATS: dict[str, dict[str, float]] = {}
SUBJECT_CONDITION_STATS: dict[str, dict[str, float]] = {}
BENCHMARK_STATS: dict[str, dict[str, float]] = {}
CONDITION_STATS: dict[str, dict[str, float]] = {}
BENCHMARK_CONDITION_STATS: dict[str, dict[str, float]] = {}
PROVIDER_STATS: dict[str, dict[str, float]] = {}
PARAM_BUCKET_STATS: dict[str, dict[str, float]] = {}
INTERCEPT = 0.0
DENSE_MEAN: list[float] = []
DENSE_SCALE: list[float] = []
DENSE_COEF: list[float] = []
HASH_COEF: list[float] = []
BLEND_WEIGHT = 0.0
OOD_BLEND_WEIGHT = 0.0
COLD_SUBJECT_BLEND_WEIGHT = 0.25
MIN_BENCHMARK_COUNT = 500
MIN_BENCHMARK_CONDITION_COUNT = 100
MIN_SUBJECT_COUNT = 20
TEMPERATURE = 1.0
CALIBRATION_CENTER = 0.5


def predict(input: dict, labeled: list[dict] | None = None) -> float:
    """Return P(correct) as a finite native Python float."""
    try:
        subject_content = str(input.get("subject_content", "") or "")
        item_content = str(input.get("item_content", "") or "")
        benchmark = str(input.get("benchmark", "") or "")
        condition = str(input.get("condition", "") or "none")
        context = _context(subject_content, benchmark, condition)

        prior = _base_prior(context)
        model_probability = _model_probability(context, item_content, prior)
        blend_weight = _effective_blend_weight(context)
        p = blend_weight * model_probability + (1.0 - blend_weight) * prior
        p = _cool_probability(p, CALIBRATION_CENTER, TEMPERATURE)
        p = _adjust_with_labeled(p, context, labeled)
        return _clip_probability(p)
    except Exception:
        return _clip_probability(GLOBAL_MEAN)


def _load_artifact() -> None:
    global EPS, HASH_DIM, DENSE_DIM, GLOBAL_MEAN
    global SUBJECT_STATS, SUBJECT_NAME_STATS, SUBJECT_ALIAS_STATS, SUBJECT_BENCHMARK_STATS, SUBJECT_CONDITION_STATS
    global BENCHMARK_STATS, CONDITION_STATS, BENCHMARK_CONDITION_STATS, PROVIDER_STATS, PARAM_BUCKET_STATS
    global INTERCEPT, DENSE_MEAN, DENSE_SCALE, DENSE_COEF, HASH_COEF
    global BLEND_WEIGHT, OOD_BLEND_WEIGHT, COLD_SUBJECT_BLEND_WEIGHT
    global MIN_BENCHMARK_COUNT, MIN_BENCHMARK_CONDITION_COUNT, MIN_SUBJECT_COUNT
    global TEMPERATURE, CALIBRATION_CENTER

    if not ARTIFACT_PATH.exists():
        return
    with ARTIFACT_PATH.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    EPS = float(payload.get("eps", EPS))
    HASH_DIM = int(payload.get("hash_dim", HASH_DIM))
    DENSE_DIM = int(payload.get("dense_dim", DENSE_DIM))
    GLOBAL_MEAN = _clip_probability(payload.get("global_mean", GLOBAL_MEAN))
    SUBJECT_STATS = payload.get("subject_stats", {}) or {}
    SUBJECT_NAME_STATS = payload.get("subject_name_stats", {}) or {}
    SUBJECT_ALIAS_STATS = payload.get("subject_alias_stats", {}) or {}
    SUBJECT_BENCHMARK_STATS = payload.get("subject_benchmark_stats", {}) or {}
    SUBJECT_CONDITION_STATS = payload.get("subject_condition_stats", {}) or {}
    BENCHMARK_STATS = payload.get("benchmark_stats", {}) or {}
    CONDITION_STATS = payload.get("condition_stats", {}) or {}
    BENCHMARK_CONDITION_STATS = payload.get("benchmark_condition_stats", {}) or {}
    PROVIDER_STATS = payload.get("provider_stats", {}) or {}
    PARAM_BUCKET_STATS = payload.get("param_bucket_stats", {}) or {}
    model = payload.get("model", {}) or {}
    INTERCEPT = float(model.get("intercept", 0.0))
    DENSE_MEAN = [float(x) for x in model.get("dense_mean", [])]
    DENSE_SCALE = [float(x) for x in model.get("dense_scale", [])]
    DENSE_COEF = [float(x) for x in model.get("dense_coefficients", [])]
    HASH_COEF = [float(x) for x in model.get("hash_coefficients", [])]
    calibration = payload.get("calibration", {}) or {}
    BLEND_WEIGHT = float(calibration.get("blend_weight", 0.0))
    OOD_BLEND_WEIGHT = float(calibration.get("ood_blend_weight", 0.0))
    COLD_SUBJECT_BLEND_WEIGHT = float(calibration.get("cold_subject_blend_weight", 0.25))
    MIN_BENCHMARK_COUNT = int(calibration.get("min_benchmark_count", 500))
    MIN_BENCHMARK_CONDITION_COUNT = int(calibration.get("min_benchmark_condition_count", 100))
    MIN_SUBJECT_COUNT = int(calibration.get("min_subject_count", 20))
    TEMPERATURE = float(calibration.get("temperature", 1.0))
    CALIBRATION_CENTER = _clip_probability(calibration.get("center", GLOBAL_MEAN))


def _context(subject_content: str, benchmark: str, condition: str) -> dict[str, str]:
    name = _extract_subject_name(subject_content)
    return {
        "subject_key": _normalize_text(subject_content),
        "subject_name": name,
        "subject_alias": _normalize_alias(name),
        "benchmark": _normalize_text(benchmark),
        "condition": _normalize_text(condition or "none"),
        "provider": _extract_subject_field(subject_content, "organization"),
        "param_bucket": _param_bucket(_extract_subject_field(subject_content, "parameters")),
    }


def _base_prior(context: dict[str, str]) -> float:
    subject_alias = context["subject_alias"]
    benchmark = context["benchmark"]
    condition = context["condition"]
    subject = _lookup_mean(SUBJECT_ALIAS_STATS, subject_alias, GLOBAL_MEAN)
    subject_benchmark = _lookup_mean(SUBJECT_BENCHMARK_STATS, f"{subject_alias}||{benchmark}", subject)
    subject_condition = _lookup_mean(SUBJECT_CONDITION_STATS, f"{subject_alias}||{condition}", subject)
    benchmark_mean = _lookup_mean(BENCHMARK_STATS, benchmark, GLOBAL_MEAN)
    benchmark_condition = _lookup_mean(BENCHMARK_CONDITION_STATS, f"{benchmark}||{condition}", benchmark_mean)
    raw = (
        0.43 * subject
        + 0.27 * subject_benchmark
        + 0.08 * subject_condition
        + 0.12 * benchmark_mean
        + 0.05 * benchmark_condition
        + 0.05 * GLOBAL_MEAN
    )
    return _clip_probability(raw)


def _effective_blend_weight(context: dict[str, str]) -> float:
    weight = _bounded_weight(BLEND_WEIGHT)
    benchmark = context["benchmark"]
    condition = context["condition"]
    benchmark_info = BENCHMARK_STATS.get(benchmark)
    benchmark_condition_info = BENCHMARK_CONDITION_STATS.get(f"{benchmark}||{condition}")
    if not benchmark_info or int(benchmark_info.get("count", 0)) < MIN_BENCHMARK_COUNT:
        weight = min(weight, _bounded_weight(OOD_BLEND_WEIGHT))
    if not benchmark_condition_info or int(benchmark_condition_info.get("count", 0)) < MIN_BENCHMARK_CONDITION_COUNT:
        weight = min(weight, _bounded_weight(OOD_BLEND_WEIGHT))

    subject_info = SUBJECT_ALIAS_STATS.get(context["subject_alias"]) or SUBJECT_NAME_STATS.get(context["subject_name"])
    if not subject_info or int(subject_info.get("count", 0)) < MIN_SUBJECT_COUNT:
        weight = min(weight, _bounded_weight(COLD_SUBJECT_BLEND_WEIGHT))
    return _bounded_weight(weight)


def _bounded_weight(value: object) -> float:
    try:
        weight = float(value)
    except Exception:
        return 0.0
    if not math.isfinite(weight):
        return 0.0
    return min(max(weight, 0.0), 1.0)


def _model_probability(context: dict[str, str], item_content: str, prior: float) -> float:
    if len(DENSE_MEAN) != DENSE_DIM or len(DENSE_SCALE) != DENSE_DIM or len(DENSE_COEF) != DENSE_DIM:
        return prior
    if len(HASH_COEF) != HASH_DIM:
        return prior
    dense = _dense_features(context, item_content)
    if len(dense) != DENSE_DIM:
        return prior
    score = INTERCEPT
    for value, mean, scale, coefficient in zip(dense, DENSE_MEAN, DENSE_SCALE, DENSE_COEF):
        denom = scale if scale else 1.0
        score += ((value - mean) / denom) * coefficient
    tokens = _feature_tokens(item_content, context["benchmark"], context["condition"], context["subject_alias"])
    if tokens:
        scale = 1.0 / math.sqrt(len(tokens))
        counts: dict[int, float] = {}
        for token in tokens:
            idx = _stable_hash(token, HASH_DIM)
            counts[idx] = counts.get(idx, 0.0) + scale
        for idx, value in counts.items():
            score += HASH_COEF[idx] * value
    return _clip_probability(_sigmoid(score))


def _dense_features(context: dict[str, str], item_content: str) -> list[float]:
    text = str(item_content or "")
    lower = text.lower()
    tokens = _tokenize(text, 100000)
    subject = _lookup_mean(SUBJECT_STATS, context["subject_key"], GLOBAL_MEAN)
    name = _lookup_mean(SUBJECT_NAME_STATS, context["subject_name"], subject)
    alias = _lookup_mean(SUBJECT_ALIAS_STATS, context["subject_alias"], name)
    subject_benchmark = _lookup_mean(SUBJECT_BENCHMARK_STATS, f"{context['subject_alias']}||{context['benchmark']}", alias)
    subject_condition = _lookup_mean(SUBJECT_CONDITION_STATS, f"{context['subject_alias']}||{context['condition']}", alias)
    benchmark = _lookup_mean(BENCHMARK_STATS, context["benchmark"], GLOBAL_MEAN)
    condition = _lookup_mean(CONDITION_STATS, context["condition"], GLOBAL_MEAN)
    benchmark_condition = _lookup_mean(BENCHMARK_CONDITION_STATS, f"{context['benchmark']}||{context['condition']}", benchmark)
    provider = _lookup_mean(PROVIDER_STATS, context["provider"], alias)
    params = _lookup_mean(PARAM_BUCKET_STATS, context["param_bucket"], alias)
    return [
        _safe_logit(subject),
        _safe_logit(name),
        _safe_logit(alias),
        _safe_logit(subject_benchmark),
        _safe_logit(subject_condition),
        _safe_logit(benchmark),
        _safe_logit(condition),
        _safe_logit(benchmark_condition),
        _safe_logit(provider),
        _safe_logit(params),
        _safe_logit(GLOBAL_MEAN),
        min(math.log1p(len(text)) / 10.0, 1.5),
        min(math.log1p(len(tokens)) / 6.0, 1.5),
        min(math.log1p(text.count("?")) / 3.0, 1.0),
        min(math.log1p(len(NUMBER_RE.findall(text))) / 4.0, 1.0),
        min(len(OPTION_RE.findall(text)) / 8.0, 1.0),
        _flag(CODE_RE.search(lower)),
        _flag(MATH_RE.search(lower)),
        _flag(MEDICAL_RE.search(lower)),
        _flag(SAFETY_RE.search(lower)),
        _flag(TOOL_RE.search(lower)),
        _flag(VISUAL_RE.search(lower)),
    ]


def _feature_tokens(item_content: str, benchmark: str, condition: str, subject_alias: str) -> list[str]:
    normalized = " ".join(str(item_content or "").lower().split())[:1600]
    words = _tokenize(normalized, 110)
    tokens = [f"b:{_normalize_text(benchmark)}", f"c:{_normalize_text(condition)}"]
    if subject_alias:
        tokens.append(f"s:{subject_alias}")
    tokens.extend(f"w:{word}" for word in words)
    tokens.extend(f"wb:{a}_{b}" for a, b in zip(words, words[1:]))
    compact = normalized.replace(" ", "_")
    for n in (3, 4, 5):
        limit = min(max(len(compact) - n + 1, 0), 800)
        step = max(1, limit // 180) if limit else 1
        for idx in range(0, limit, step):
            tokens.append(f"c{n}:{compact[idx:idx+n]}")
    return tokens


def _adjust_with_labeled(p: float, context: dict[str, str], labeled: list[dict] | None) -> float:
    if not labeled:
        return p
    all_values: list[float] = []
    same_subject: list[float] = []
    same_benchmark: list[float] = []
    same_condition: list[float] = []
    for row in labeled:
        try:
            visible = row.get("input", row)
            label = float(row.get("label", row.get("response", row.get("correct"))))
            if not math.isfinite(label):
                continue
            value = 1.0 if label >= 0.5 else 0.0
            all_values.append(value)
            row_context = _context(
                str(visible.get("subject_content", "") or ""),
                str(visible.get("benchmark", "") or ""),
                str(visible.get("condition", "") or "none"),
            )
            if row_context["subject_alias"] == context["subject_alias"]:
                same_subject.append(value)
            if row_context["benchmark"] == context["benchmark"]:
                same_benchmark.append(value)
            if row_context["condition"] == context["condition"]:
                same_condition.append(value)
        except Exception:
            continue
    if not all_values:
        return p
    adjusted = p
    adjusted = _label_shift(adjusted, all_values, GLOBAL_MEAN, 0.30, 10.0)
    adjusted = _label_shift(adjusted, same_subject, GLOBAL_MEAN, 0.28, 4.0)
    adjusted = _label_shift(adjusted, same_benchmark, GLOBAL_MEAN, 0.18, 6.0)
    adjusted = _label_shift(adjusted, same_condition, GLOBAL_MEAN, 0.10, 8.0)
    return adjusted


def _label_shift(p: float, values: list[float], center: float, max_weight: float, shrink: float) -> float:
    if not values:
        return p
    observed = sum(values) / len(values)
    weight = max_weight * (len(values) / (len(values) + shrink))
    return p + weight * (observed - center)


def _extract_subject_name(subject_content: str) -> str:
    for line in str(subject_content or "").splitlines():
        if line.lower().startswith("name:"):
            return _normalize_text(line.split(":", 1)[1])
    return ""


def _extract_subject_field(subject_content: str, label: str) -> str:
    prefix = f"{label}:"
    for line in str(subject_content or "").splitlines():
        if line.lower().startswith(prefix):
            return _normalize_alias(line.split(":", 1)[1])
    return ""


def _param_bucket(text: object) -> str:
    match = re.search(r"(\d+(?:\.\d+)?)\s*b", str(text or "").lower())
    if not match:
        return ""
    params = float(match.group(1))
    if params < 4:
        return "lt4b"
    if params < 10:
        return "4to10b"
    if params < 30:
        return "10to30b"
    if params < 80:
        return "30to80b"
    return "gte80b"


def _lookup_mean(stats: dict[str, dict[str, float]], key: object, fallback: float) -> float:
    info = stats.get(str(key))
    if not info:
        return float(fallback)
    try:
        return float(info.get("mean", fallback))
    except Exception:
        return float(fallback)


def _normalize_text(text: object) -> str:
    return " ".join(str(text or "").lower().strip().split())


def _normalize_alias(text: object) -> str:
    value = str(text or "").lower()
    value = value.replace("instruct", "inst")
    value = value.replace("chat", "")
    return ALIAS_RE.sub("", value)


def _tokenize(text: str, limit: int) -> list[str]:
    return [match.group(0).lower() for match in TOKEN_RE.finditer(str(text or ""))][:limit]


def _stable_hash(text: str, modulo: int) -> int:
    digest = hashlib.blake2b(text.encode("utf-8", errors="ignore"), digest_size=8).digest()
    return int.from_bytes(digest, "little") % modulo


def _safe_logit(value: float) -> float:
    value = _clip_probability(value)
    return math.log(value / (1.0 - value))


def _sigmoid(value: float) -> float:
    value = min(max(float(value), -30.0), 30.0)
    return 1.0 / (1.0 + math.exp(-value))


def _cool_probability(value: float, center: float, temperature: float) -> float:
    value = _clip_probability(value)
    center = _clip_probability(center)
    logit = math.log(value / (1.0 - value))
    center_logit = math.log(center / (1.0 - center))
    return _sigmoid(center_logit + (logit - center_logit) / max(float(temperature), 0.1))


def _flag(value: object) -> float:
    return 1.0 if value else 0.0


def _clip_probability(value: object) -> float:
    try:
        p = float(value)
    except Exception:
        return float(GLOBAL_MEAN)
    if not math.isfinite(p):
        return float(GLOBAL_MEAN)
    if p < EPS:
        return float(EPS)
    if p > 1.0 - EPS:
        return float(1.0 - EPS)
    return float(p)


_load_artifact()
