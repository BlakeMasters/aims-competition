"""Conservative uncertainty acquisition for hierarchical OOD log-loss candidates."""

from __future__ import annotations

import hashlib
import math

import model


def acquisition_function(input: dict) -> float:
    """Prioritize examples closest to the model's probability center."""
    try:
        p = float(model.predict(dict(input), labeled=[]))
        if not math.isfinite(p):
            p = 0.5
        p = min(max(p, 1e-4), 1.0 - 1e-4)
        tie_break = _stable_unit(_row_key(input)) * 1e-9
        return float(p * (1.0 - p) + tie_break)
    except Exception:
        return 0.0


def _row_key(input: dict) -> str:
    return "\n".join(
        [
            str(input.get("benchmark", "") or ""),
            str(input.get("condition", "") or ""),
            str(input.get("subject_content", "") or "")[:300],
            str(input.get("item_content", "") or "")[:1000],
        ]
    )


def _stable_unit(text: str) -> float:
    digest = hashlib.blake2b(str(text).encode("utf-8", errors="ignore"), digest_size=8).digest()
    return int.from_bytes(digest, "little") / float(2**64 - 1)
