"""Compact subject scaling-law prior runtime."""

from __future__ import annotations

import json
import math
import re
from pathlib import Path


ARTIFACT_PATH = Path(__file__).resolve().parent / "artifacts" / "scaling_law.json"
ALIAS_RE = re.compile(r"[^a-z0-9]+")
EPS = 1e-4
GLOBAL_MEAN = 0.55
SUBJECT_ALIAS_STATS = {}
PROVIDER_PARAM_STATS = {}
PROVIDER_STATS = {}
PARAM_BUCKET_STATS = {}
RELEASE_BUCKET_STATS = {}
FAMILY_STATS = {}
FORMULA = {}


def predict(input: dict, labeled: list[dict] | None = None) -> float:
    try:
        subject = str(input.get("subject_content", "") or "")
        alias = _normalize_alias(_extract_subject_field(subject, "name"))
        provider = _normalize_alias(_extract_subject_field(subject, "organization"))
        params = _param_bucket(_extract_subject_field(subject, "parameters"))
        release = _release_bucket(_extract_subject_field(subject, "released"))
        family = _family_token(subject)
        provider_param = provider + "||" + params
        center_raw = FORMULA.get("center")
        center = GLOBAL_MEAN if center_raw is None else _clip(center_raw)
        subject_p = _lookup(SUBJECT_ALIAS_STATS, alias, GLOBAL_MEAN)
        provider_param_p = _lookup(PROVIDER_PARAM_STATS, provider_param, GLOBAL_MEAN)
        provider_p = _lookup(PROVIDER_STATS, provider, GLOBAL_MEAN)
        param_p = _lookup(PARAM_BUCKET_STATS, params, GLOBAL_MEAN)
        release_p = _lookup(RELEASE_BUCKET_STATS, release, GLOBAL_MEAN)
        family_p = _lookup(FAMILY_STATS, family, GLOBAL_MEAN)
        raw = center + float(FORMULA.get("strength", 1.0)) * (
            float(FORMULA.get("subject_weight", 0.0)) * (subject_p - center)
            + float(FORMULA.get("provider_param_weight", 0.0)) * (provider_param_p - center)
            + float(FORMULA.get("provider_weight", 0.0)) * (provider_p - center)
            + float(FORMULA.get("param_weight", 0.0)) * (param_p - center)
            + float(FORMULA.get("release_weight", 0.0)) * (release_p - center)
            + float(FORMULA.get("family_weight", 0.0)) * (family_p - center)
        )
        p = _cool(raw, center, float(FORMULA.get("temperature", 1.0)))
        p = _adjust_with_labeled(_clip(p), alias, labeled, center)
        return _clip(p)
    except Exception:
        return _clip(GLOBAL_MEAN)


def _load_artifact() -> None:
    global EPS, GLOBAL_MEAN, SUBJECT_ALIAS_STATS, PROVIDER_PARAM_STATS, PROVIDER_STATS
    global PARAM_BUCKET_STATS, RELEASE_BUCKET_STATS, FAMILY_STATS, FORMULA
    if not ARTIFACT_PATH.exists():
        return
    with ARTIFACT_PATH.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    EPS = float(payload.get("eps", EPS))
    GLOBAL_MEAN = _clip(payload.get("global_mean", GLOBAL_MEAN))
    SUBJECT_ALIAS_STATS = payload.get("subject_alias_stats", {}) or {}
    PROVIDER_PARAM_STATS = payload.get("provider_param_stats", {}) or {}
    PROVIDER_STATS = payload.get("provider_stats", {}) or {}
    PARAM_BUCKET_STATS = payload.get("param_bucket_stats", {}) or {}
    RELEASE_BUCKET_STATS = payload.get("release_bucket_stats", {}) or {}
    FAMILY_STATS = payload.get("family_stats", {}) or {}
    FORMULA.update(payload.get("runtime_formula", {}) or {})


def _adjust_with_labeled(p: float, alias: str, labeled: list[dict] | None, center: float) -> float:
    if not labeled:
        return p
    all_values = []
    same_subject = []
    for row in labeled:
        try:
            visible = row.get("input", row)
            label = float(row.get("label", row.get("response", row.get("correct"))))
            if not math.isfinite(label):
                continue
            value = 1.0 if label >= 0.5 else 0.0
            all_values.append(value)
            if _normalize_alias(_extract_subject_field(str(visible.get("subject_content", "") or ""), "name")) == alias:
                same_subject.append(value)
        except Exception:
            continue
    adjusted = _label_shift(p, all_values, center, 0.05, 24.0)
    adjusted = _label_shift(adjusted, same_subject, center, 0.08, 6.0)
    return adjusted


def _label_shift(p: float, values: list[float], center: float, max_weight: float, shrink: float) -> float:
    if not values:
        return p
    observed = sum(values) / len(values)
    weight = max_weight * (len(values) / (len(values) + shrink))
    return p + weight * (observed - center)


def _extract_subject_field(subject_content: str, field: str) -> str:
    prefix = field.lower() + ":"
    for line in str(subject_content or "").splitlines():
        if line.lower().startswith(prefix):
            return line.split(":", 1)[1]
    return ""


def _family_token(text: str) -> str:
    value = str(text or "").lower()
    patterns = [
        ("gpt", r"\bgpt|o1|o3|o4"),
        ("claude", r"claude|anthropic"),
        ("gemini", r"gemini|palm|bard"),
        ("llama", r"llama|meta"),
        ("qwen", r"qwen"),
        ("mistral", r"mistral|mixtral|codestral"),
        ("deepseek", r"deepseek"),
        ("yi", r"\byi[- ]"),
        ("phi", r"\bphi[- ]"),
        ("command", r"command|cohere"),
        ("gemma", r"gemma"),
        ("mpt", r"\bmpt"),
        ("falcon", r"falcon"),
    ]
    for name, pattern in patterns:
        if re.search(pattern, value):
            return name
    return "generic"


def _param_bucket(text: object) -> str:
    match = re.search(r"(\d+(?:\.\d+)?)\s*b", str(text or "").lower())
    if not match:
        return ""
    params = float(match.group(1))
    if params < 4:
        return "lt4b"
    if params < 10:
        return "4to10b"
    if params < 30:
        return "10to30b"
    if params < 80:
        return "30to80b"
    return "gte80b"


def _release_bucket(text: object) -> str:
    match = re.search(r"(20\d{2})", str(text or ""))
    if not match:
        return ""
    year = int(match.group(1))
    if year <= 2022:
        return "le2022"
    if year == 2023:
        return "2023"
    if year == 2024:
        return "2024"
    if year >= 2025:
        return "ge2025"
    return ""


def _lookup(stats: dict, key: object, fallback: float) -> float:
    value = stats.get(str(key))
    if value is None:
        return float(fallback)
    try:
        if isinstance(value, list):
            return float(value[0])
        return float(value.get("mean", fallback))
    except Exception:
        return float(fallback)


def _normalize_alias(text: object) -> str:
    value = str(text or "").lower()
    value = value.replace("instruct", "inst").replace("chat", "")
    return ALIAS_RE.sub("", value)


def _cool(value: float, center: float, temperature: float) -> float:
    temperature = max(float(temperature), 0.1)
    return _sigmoid(_logit(center) + (_logit(value) - _logit(center)) / temperature)


def _logit(value: float) -> float:
    p = _clip(value)
    return math.log(p / (1.0 - p))


def _sigmoid(value: float) -> float:
    value = max(min(float(value), 30.0), -30.0)
    return 1.0 / (1.0 + math.exp(-value))


def _clip(value) -> float:
    try:
        p = float(value)
    except Exception:
        return float(GLOBAL_MEAN)
    if not math.isfinite(p):
        return float(GLOBAL_MEAN)
    return min(max(p, EPS), 1.0 - EPS)


_load_artifact()
