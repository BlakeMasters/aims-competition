"""Conservative forecast stack for negative log-loss."""

from __future__ import annotations

import importlib.util
import json
import math
from pathlib import Path


ARTIFACT_PATH = Path(__file__).resolve().parent / "artifacts" / "forecast_logloss.json"
CONFIG = {
    "center": 0.57,
    "domain_weight": 0.56,
    "scaling_weight": 0.10,
    "text_weight": 0.16,
    "sparse_weight": 0.12,
    "clean_weight": 0.06,
    "strength": 0.72,
    "temperature": 1.55,
    "floor": 0.30,
    "ceiling": 0.78,
}
DOMAIN = None
SCALING = None
TEXT = None
SPARSE = None
CLEAN = None


def predict(input: dict, labeled: list[dict] | None = None) -> float:
    try:
        _load_models()
        row = dict(input)
        center = _clip(CONFIG.get("center", 0.57))
        center_logit = _logit(center)
        components = [
            ("domain_weight", _clip(DOMAIN.predict(row, labeled=labeled))),
            ("scaling_weight", _clip(SCALING.predict(row, labeled=labeled))),
            ("text_weight", _clip(TEXT.predict(row, labeled=labeled))),
            ("sparse_weight", _clip(SPARSE.predict(row, labeled=labeled))),
            ("clean_weight", _clip(CLEAN.predict(row, labeled=labeled))),
        ]
        total = 0.0
        raw = 0.0
        for weight_name, value in components:
            weight = max(float(CONFIG.get(weight_name, 0.0)), 0.0)
            if weight <= 0.0:
                continue
            total += weight
            raw += weight * (_logit(value) - center_logit)
        if total > 0.0:
            raw /= total
        strength = float(CONFIG.get("strength", 1.0))
        temperature = max(float(CONFIG.get("temperature", 1.0)), 0.1)
        p = _sigmoid(center_logit + strength * raw / temperature)
        p = _clip(p)
        floor = _clip(CONFIG.get("floor", 1e-4))
        ceiling = _clip(CONFIG.get("ceiling", 1.0 - 1e-4))
        if floor > ceiling:
            floor, ceiling = ceiling, floor
        return min(max(p, floor), ceiling)
    except Exception:
        return _clip(CONFIG.get("center", 0.57))


def _load_models() -> None:
    global DOMAIN, SCALING, TEXT, SPARSE, CLEAN
    if DOMAIN is not None and SCALING is not None and TEXT is not None and SPARSE is not None and CLEAN is not None:
        return
    root = Path(__file__).resolve().parent
    DOMAIN = _load_module(root / "domain_model.py", "forecast_domain_model")
    SCALING = _load_module(root / "scaling_model.py", "forecast_scaling_model")
    TEXT = _load_module(root / "text_model.py", "forecast_text_model")
    SPARSE = _load_module(root / "sparse_model.py", "forecast_sparse_model")
    CLEAN = _load_module(root / "clean_model.py", "forecast_clean_model")


def _load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"could not load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _load_config() -> None:
    global CONFIG
    if not ARTIFACT_PATH.exists():
        return
    try:
        payload = json.loads(ARTIFACT_PATH.read_text(encoding="utf-8"))
        CONFIG.update(payload.get("formula", {}) or {})
    except Exception:
        pass


def _clip(value) -> float:
    try:
        p = float(value)
    except Exception:
        return 0.57
    if not math.isfinite(p):
        return 0.57
    return min(max(p, 1e-4), 1.0 - 1e-4)


def _logit(value: float) -> float:
    p = _clip(value)
    return math.log(p / (1.0 - p))


def _sigmoid(value: float) -> float:
    value = max(min(float(value), 30.0), -30.0)
    return 1.0 / (1.0 + math.exp(-value))


_load_config()
