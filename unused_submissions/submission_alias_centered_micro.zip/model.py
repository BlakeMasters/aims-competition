"""Runtime submission for the Predictive AI Evaluation Challenge.

This module intentionally depends only on the Python standard library. The
offline trainer writes artifacts/stats.json with priors and a compact hashed
linear model.
"""

from __future__ import annotations

import hashlib
import json
import math
import re
from pathlib import Path


ARTIFACT_DIR = Path(__file__).resolve().parent / "artifacts"
STATS_PATH = ARTIFACT_DIR / "stats.json"
TOKEN_RE = re.compile(r"[A-Za-z0-9_./:+-]{2,}")
ALIAS_RE = re.compile(r"[^a-z0-9]+")
OPTION_RE = re.compile(r"(?:^|\n|\s)(?:\(?[A-Ha-h]\)?[\).:]|option\s+[A-Ha-h]\b)")
NUMBER_RE = re.compile(r"[-+]?\d+(?:\.\d+)?")
CODE_RE = re.compile(r"\b(def|class|import|return|function|public|private|const|let|var|python|java|javascript|sql|bash|stack trace|exception)\b|```|[{};]")
MATH_RE = re.compile(r"\b(prove|theorem|equation|integral|derivative|matrix|geometry|probability|calculate|solve|integer)\b|[=+\-*/^<>]")
MEDICAL_RE = re.compile(r"\b(patient|diagnosis|clinical|treatment|symptom|disease|drug|dose|medical|doctor|hospital|therapy)\b")
SAFETY_RE = re.compile(r"\b(safety|harm|attack|exploit|malware|toxic|bias|jailbreak|policy|privacy|secure|risk)\b")
TOOL_RE = re.compile(r"\b(api|tool|function call|json|browser|android|web|terminal|shell|agent|environment)\b")
VISUAL_RE = re.compile(r"\b(image|diagram|figure|chart|graph|picture|visual|screenshot|bounding box)\b")

EPS = 1e-4
HASH_DIM = 2048
DENSE_DIM = 6
GLOBAL_MEAN = 0.5
HIDDEN_BASE_RATE = 0.6571
TEXT_WEIGHT = 0.0
SUBJECT_STATS: dict[str, dict[str, float]] = {}
SUBJECT_NAME_STATS: dict[str, dict[str, float]] = {}
SUBJECT_ALIAS_STATS: dict[str, dict[str, float]] = {}
PROVIDER_STATS: dict[str, dict[str, float]] = {}
PARAM_BUCKET_STATS: dict[str, dict[str, float]] = {}
CONDITION_STATS: dict[str, dict[str, float]] = {}
BENCHMARK_STATS: dict[str, dict[str, float]] = {}
INTERCEPT = 0.0
COEFFICIENTS: list[float] = []
ENGINEERED_MODEL: dict[str, object] = {}
SEMANTIC_MODEL: dict[str, object] = {}
RUNTIME_FORMULA = {
    "center": 0.6571,
    "subject_weight": 0.58,
    "name_weight": 0.12,
    "condition_weight": 0.18,
    "benchmark_weight": 0.07,
    "global_weight": 0.05,
    "strength": 1.0,
}


def _load_artifacts() -> None:
    global EPS, HASH_DIM, DENSE_DIM, GLOBAL_MEAN, HIDDEN_BASE_RATE, TEXT_WEIGHT
    global SUBJECT_STATS, SUBJECT_NAME_STATS, SUBJECT_ALIAS_STATS, PROVIDER_STATS, PARAM_BUCKET_STATS
    global CONDITION_STATS, BENCHMARK_STATS
    global INTERCEPT, COEFFICIENTS, ENGINEERED_MODEL, SEMANTIC_MODEL, RUNTIME_FORMULA

    if not STATS_PATH.exists():
        return
    with STATS_PATH.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)

    EPS = float(payload.get("eps", EPS))
    HASH_DIM = int(payload.get("hash_dim", HASH_DIM))
    DENSE_DIM = int(payload.get("dense_dim", DENSE_DIM))
    GLOBAL_MEAN = _clip_probability(payload.get("global_mean", GLOBAL_MEAN))
    HIDDEN_BASE_RATE = _clip_probability(payload.get("hidden_base_rate", HIDDEN_BASE_RATE))
    TEXT_WEIGHT = float(payload.get("text_weight", 0.0))
    SUBJECT_STATS = payload.get("subject_stats", {}) or {}
    SUBJECT_NAME_STATS = payload.get("subject_name_stats", {}) or {}
    SUBJECT_ALIAS_STATS = payload.get("subject_alias_stats", {}) or {}
    PROVIDER_STATS = payload.get("provider_stats", {}) or {}
    PARAM_BUCKET_STATS = payload.get("param_bucket_stats", {}) or {}
    CONDITION_STATS = payload.get("condition_stats", {}) or {}
    BENCHMARK_STATS = payload.get("benchmark_stats", {}) or {}
    RUNTIME_FORMULA.update(payload.get("runtime_formula", {}) or {})

    model = payload.get("model", {}) or {}
    INTERCEPT = float(model.get("intercept", 0.0))
    COEFFICIENTS = [float(value) for value in model.get("coefficients", [])]
    ENGINEERED_MODEL = payload.get("engineered_model", {}) or {}
    SEMANTIC_MODEL = payload.get("semantic_model", {}) or {}


def predict(input: dict, labeled: list[dict] | None = None) -> float:
    """Return P(correct) as a native float in [0, 1]."""
    try:
        subject_content = str(input.get("subject_content", "") or "")
        item_content = str(input.get("item_content", "") or "")
        benchmark = str(input.get("benchmark", "") or "")
        condition = str(input.get("condition", "") or "none")

        subject_key = _normalize_text(subject_content)
        subject_name = _extract_subject_name(subject_content)
        prior = _base_prior(subject_key, subject_name, subject_content, condition, benchmark)
        semantic_probability = _semantic_model_probability(
            subject_key=subject_key,
            subject_name=subject_name,
            item_content=item_content,
            condition=condition,
            prior=prior,
        )
        semantic_weight = float(RUNTIME_FORMULA.get("semantic_weight", SEMANTIC_MODEL.get("blend_weight", 0.0) or 0.0))
        p = (semantic_weight * semantic_probability) + ((1.0 - semantic_weight) * prior)
        engineered_probability = _engineered_model_probability(
            subject_key=subject_key,
            subject_name=subject_name,
            subject_content=subject_content,
            item_content=item_content,
            benchmark=benchmark,
            condition=condition,
            prior=p,
        )
        engineered_weight = float(RUNTIME_FORMULA.get("engineered_weight", ENGINEERED_MODEL.get("blend_weight", 0.0) or 0.0))
        p = (engineered_weight * engineered_probability) + ((1.0 - engineered_weight) * p)
        text_probability = _text_model_probability(
            subject_key=subject_key,
            subject_name=subject_name,
            subject_content=subject_content,
            item_content=item_content,
            benchmark=benchmark,
            condition=condition,
            prior=prior,
        )
        p = (TEXT_WEIGHT * text_probability) + ((1.0 - TEXT_WEIGHT) * p)
        p = _adjust_with_labeled(p, subject_key, benchmark, condition, labeled)
        return _clip_probability(p)
    except Exception:
        return _clip_probability(GLOBAL_MEAN)


def _base_prior(subject_key: str, subject_name: str, subject_content: str, condition: str, benchmark: str) -> float:
    subject = _lookup_mean(SUBJECT_STATS, subject_key, GLOBAL_MEAN)
    name_prior = _lookup_mean(SUBJECT_NAME_STATS, subject_name, subject)
    alias_prior = _lookup_mean(SUBJECT_ALIAS_STATS, _normalize_alias(subject_name), name_prior)
    provider_prior = _lookup_mean(PROVIDER_STATS, _extract_subject_field(subject_content, "organization"), alias_prior)
    param_prior = _lookup_mean(PARAM_BUCKET_STATS, _param_bucket(_extract_subject_field(subject_content, "parameters")), alias_prior)
    condition_prior = _lookup_mean(CONDITION_STATS, _normalize_text(condition), GLOBAL_MEAN)
    benchmark_prior = _lookup_mean(BENCHMARK_STATS, _normalize_text(benchmark), GLOBAL_MEAN)
    center = RUNTIME_FORMULA.get("center")
    if center is None:
        center_value = HIDDEN_BASE_RATE
    else:
        center_value = float(center)
    subject_weight = float(RUNTIME_FORMULA.get("subject_weight", 0.58))
    name_weight = float(RUNTIME_FORMULA.get("name_weight", 0.12))
    alias_weight = float(RUNTIME_FORMULA.get("alias_weight", 0.0))
    provider_weight = float(RUNTIME_FORMULA.get("provider_weight", 0.0))
    param_weight = float(RUNTIME_FORMULA.get("param_weight", 0.0))
    condition_weight = float(RUNTIME_FORMULA.get("condition_weight", 0.18))
    benchmark_weight = float(RUNTIME_FORMULA.get("benchmark_weight", 0.07))
    global_weight = float(RUNTIME_FORMULA.get("global_weight", 0.05))
    strength = float(RUNTIME_FORMULA.get("strength", 1.0))
    raw = (
        center_value
        + subject_weight * (subject - center_value)
        + name_weight * (name_prior - center_value)
        + alias_weight * (alias_prior - center_value)
        + provider_weight * (provider_prior - center_value)
        + param_weight * (param_prior - center_value)
        + condition_weight * (condition_prior - center_value)
        + benchmark_weight * (benchmark_prior - center_value)
        + global_weight * (GLOBAL_MEAN - center_value)
    )
    p = center_value + strength * (raw - center_value)
    return _clip_probability(p)


def _semantic_model_probability(
    *,
    subject_key: str,
    subject_name: str,
    item_content: str,
    condition: str,
    prior: float,
) -> float:
    if not SEMANTIC_MODEL or not SEMANTIC_MODEL.get("enabled", False):
        return prior
    hash_dim = int(SEMANTIC_MODEL.get("hash_dim", 0) or 0)
    dense_dim = int(SEMANTIC_MODEL.get("dense_dim", 0) or 0)
    coefficients = [float(value) for value in SEMANTIC_MODEL.get("coefficients", [])]
    if hash_dim <= 0 or dense_dim <= 0 or len(coefficients) != hash_dim + dense_dim:
        return prior
    dense = _semantic_dense_features(subject_key, subject_name, condition)
    if len(dense) != dense_dim:
        return prior
    score = float(SEMANTIC_MODEL.get("intercept", 0.0))
    for idx, value in enumerate(dense):
        score += coefficients[idx] * value
    tokens = _semantic_tokens(item_content, condition, subject_name)
    if tokens:
        scale = 1.0 / math.sqrt(len(tokens))
        for token in tokens:
            score += coefficients[dense_dim + _stable_hash(token, hash_dim)] * scale
    probability = _sigmoid(score)
    temperature = float(SEMANTIC_MODEL.get("temperature", 1.0) or 1.0)
    return _cool_probability(probability, HIDDEN_BASE_RATE, temperature)


def _semantic_dense_features(subject_key: str, subject_name: str, condition: str) -> list[float]:
    subject = _lookup_mean(SUBJECT_STATS, subject_key, GLOBAL_MEAN)
    name_prior = _lookup_mean(SUBJECT_NAME_STATS, subject_name, subject)
    condition_prior = _lookup_mean(CONDITION_STATS, _normalize_text(condition), GLOBAL_MEAN)
    return [
        subject - HIDDEN_BASE_RATE,
        name_prior - HIDDEN_BASE_RATE,
        condition_prior - HIDDEN_BASE_RATE,
        GLOBAL_MEAN - HIDDEN_BASE_RATE,
        0.0,
        1.0,
    ]


def _semantic_tokens(item_text: str, condition: str, subject_name: str) -> list[str]:
    normalized = " ".join(str(item_text or "").lower().split())[:1000]
    words = _tokenize(normalized, 90)
    tokens = [f"cond:{str(condition or '').lower()}", f"subj:{str(subject_name or '').lower()}"]
    tokens.extend(f"w:{word}" for word in words)
    tokens.extend(f"wb:{a}_{b}" for a, b in zip(words, words[1:]))
    compact = normalized.replace(" ", "_")
    for n in (3, 4, 5):
        limit = min(max(len(compact) - n + 1, 0), 600)
        step = max(1, limit // 150) if limit else 1
        for idx in range(0, limit, step):
            tokens.append(f"c{n}:{compact[idx:idx+n]}")
    return tokens


def _engineered_model_probability(
    *,
    subject_key: str,
    subject_name: str,
    subject_content: str,
    item_content: str,
    benchmark: str,
    condition: str,
    prior: float,
) -> float:
    if not ENGINEERED_MODEL or not ENGINEERED_MODEL.get("enabled", False):
        return prior
    coefficients = [float(value) for value in ENGINEERED_MODEL.get("coefficients", [])]
    means = [float(value) for value in ENGINEERED_MODEL.get("scaler_mean", [])]
    scales = [float(value) for value in ENGINEERED_MODEL.get("scaler_scale", [])]
    features = _engineered_features(subject_key, subject_name, subject_content, item_content, benchmark, condition)
    if len(coefficients) != len(features) or len(means) != len(features) or len(scales) != len(features):
        return prior
    score = float(ENGINEERED_MODEL.get("intercept", 0.0))
    for value, mean, scale, coefficient in zip(features, means, scales, coefficients):
        denom = scale if scale else 1.0
        score += ((value - mean) / denom) * coefficient
    probability = _sigmoid(score)
    temperature = float(ENGINEERED_MODEL.get("temperature", 1.0) or 1.0)
    return _cool_probability(probability, HIDDEN_BASE_RATE, temperature)


def _engineered_features(
    subject_key: str,
    subject_name: str,
    subject_content: str,
    item_content: str,
    benchmark: str,
    condition: str,
) -> list[float]:
    text = str(item_content or "")
    lower = text.lower()
    condition_lower = str(condition or "").lower()
    tokens = _tokenize(text, 100000)
    subject = _lookup_mean(SUBJECT_STATS, subject_key, GLOBAL_MEAN)
    name_prior = _lookup_mean(SUBJECT_NAME_STATS, subject_name, subject)
    condition_prior = _lookup_mean(CONDITION_STATS, _normalize_text(condition), GLOBAL_MEAN)
    benchmark_prior = _lookup_mean(BENCHMARK_STATS, _normalize_text(benchmark), GLOBAL_MEAN)
    return [
        subject - HIDDEN_BASE_RATE,
        name_prior - HIDDEN_BASE_RATE,
        condition_prior - HIDDEN_BASE_RATE,
        benchmark_prior - HIDDEN_BASE_RATE,
        min(math.log1p(len(text)) / 10.0, 1.5),
        min(math.log1p(len(tokens)) / 6.0, 1.5),
        min(math.log1p(text.count("?")) / 3.0, 1.0),
        min(math.log1p(len(NUMBER_RE.findall(text))) / 4.0, 1.0),
        min(len(OPTION_RE.findall(text)) / 8.0, 1.0),
        _flag(CODE_RE.search(lower)),
        _flag(MATH_RE.search(lower)),
        _flag(MEDICAL_RE.search(lower)),
        _flag(SAFETY_RE.search(lower)),
        _flag(TOOL_RE.search(lower)),
        _flag(VISUAL_RE.search(lower)),
        _flag("few" in condition_lower),
        _flag("zero" in condition_lower or condition_lower == "none"),
        min(math.log1p(len(subject_content)) / 8.0, 1.0),
    ]


def _text_model_probability(
    *,
    subject_key: str,
    subject_name: str,
    subject_content: str,
    item_content: str,
    benchmark: str,
    condition: str,
    prior: float,
) -> float:
    expected_width = DENSE_DIM + HASH_DIM
    if len(COEFFICIENTS) != expected_width:
        return prior

    dense = [
        _lookup_mean(SUBJECT_STATS, subject_key, GLOBAL_MEAN),
        _lookup_mean(SUBJECT_NAME_STATS, subject_name, prior),
        _lookup_mean(CONDITION_STATS, _normalize_text(condition), GLOBAL_MEAN),
        _lookup_mean(BENCHMARK_STATS, _normalize_text(benchmark), GLOBAL_MEAN),
        min(math.log1p(len(item_content)) / 10.0, 1.0),
        min(math.log1p(len(subject_content)) / 8.0, 1.0),
    ]
    score = INTERCEPT
    for idx, value in enumerate(dense):
        score += COEFFICIENTS[idx] * value

    tokens = _feature_tokens(benchmark, condition, subject_name, subject_content, item_content)
    if tokens:
        scale = 1.0 / math.sqrt(len(tokens))
        for token in tokens:
            score += COEFFICIENTS[DENSE_DIM + _stable_hash(token, HASH_DIM)] * scale
    return _clip_probability(_sigmoid(score))


def _adjust_with_labeled(
    p: float,
    subject_key: str,
    benchmark: str,
    condition: str,
    labeled: list[dict] | None,
) -> float:
    if not labeled:
        return p
    all_values: list[float] = []
    same_subject: list[float] = []
    same_benchmark: list[float] = []
    same_condition: list[float] = []
    benchmark_key = _normalize_text(benchmark)
    condition_key = _normalize_text(condition)
    for row in labeled:
        try:
            visible = row.get("input", row)
            row_subject = _normalize_text(visible.get("subject_content", ""))
            row_benchmark = _normalize_text(visible.get("benchmark", ""))
            row_condition = _normalize_text(visible.get("condition", ""))
            label = row.get("label", row.get("response", row.get("correct")))
            label_value = float(label)
            if math.isfinite(label_value):
                value = 1.0 if label_value >= 0.5 else 0.0
                all_values.append(value)
                if row_subject == subject_key:
                    same_subject.append(value)
                if row_benchmark == benchmark_key:
                    same_benchmark.append(value)
                if row_condition == condition_key:
                    same_condition.append(value)
        except Exception:
            continue
    if not all_values:
        return p
    adjusted = p
    adjusted = _label_shift(adjusted, all_values, HIDDEN_BASE_RATE, 0.45, 8.0)
    adjusted = _label_shift(adjusted, same_subject, HIDDEN_BASE_RATE, 0.35, 3.0)
    adjusted = _label_shift(adjusted, same_benchmark, HIDDEN_BASE_RATE, 0.20, 5.0)
    adjusted = _label_shift(adjusted, same_condition, HIDDEN_BASE_RATE, 0.10, 8.0)
    return adjusted


def _label_shift(p: float, values: list[float], center: float, max_weight: float, shrink: float) -> float:
    if not values:
        return p
    count = len(values)
    observed = sum(values) / count
    weight = max_weight * (count / (count + shrink))
    return p + weight * (observed - center)


def _feature_tokens(
    benchmark: str,
    condition: str,
    subject_name: str,
    subject_text: str,
    item_text: str,
) -> list[str]:
    tokens = [f"benchmark={_normalize_text(benchmark)}", f"condition={_normalize_text(condition)}"]
    if subject_name:
        tokens.append(f"subject={subject_name}")
    subject_words = _tokenize(subject_text, 24)
    item_words = _tokenize(item_text, 64)
    tokens.extend(f"sub:{word}" for word in subject_words)
    tokens.extend(f"item:{word}" for word in item_words)
    tokens.extend(f"item2:{a}_{b}" for a, b in zip(item_words, item_words[1:]))
    return tokens


def _extract_subject_name(subject_content: str) -> str:
    for line in str(subject_content or "").splitlines():
        if line.lower().startswith("name:"):
            return _normalize_text(line.split(":", 1)[1])
    return ""


def _extract_subject_field(subject_content: str, label: str) -> str:
    prefix = f"{label}:"
    for line in str(subject_content or "").splitlines():
        if line.lower().startswith(prefix):
            return _normalize_alias(line.split(":", 1)[1])
    return ""


def _tokenize(text: str, limit: int) -> list[str]:
    return [match.group(0).lower() for match in TOKEN_RE.finditer(str(text or ""))][:limit]


def _lookup_mean(stats: dict[str, dict[str, float]], key: object, fallback: float) -> float:
    info = stats.get(str(key))
    if info is None:
        return float(fallback)
    try:
        return float(info.get("mean", fallback))
    except Exception:
        return float(fallback)


def _normalize_text(text: object) -> str:
    return " ".join(str(text or "").lower().strip().split())


def _normalize_alias(text: object) -> str:
    value = str(text or "").lower()
    value = value.replace("instruct", "inst")
    return ALIAS_RE.sub("", value)


def _param_bucket(text: object) -> str:
    match = re.search(r"(\d+(?:\.\d+)?)\s*b", str(text or "").lower())
    if not match:
        return ""
    params = float(match.group(1))
    if params < 4:
        return "lt4b"
    if params < 10:
        return "4to10b"
    if params < 30:
        return "10to30b"
    if params < 80:
        return "30to80b"
    return "gte80b"


def _stable_hash(text: str, modulo: int) -> int:
    digest = hashlib.blake2b(text.encode("utf-8", errors="ignore"), digest_size=8).digest()
    return int.from_bytes(digest, "little") % modulo


def _sigmoid(value: float) -> float:
    value = min(max(float(value), -30.0), 30.0)
    return 1.0 / (1.0 + math.exp(-value))


def _cool_probability(value: float, center: float, temperature: float) -> float:
    value = _clip_probability(value)
    center = _clip_probability(center)
    temperature = max(float(temperature), 0.1)
    logit = math.log(value / (1.0 - value))
    center_logit = math.log(center / (1.0 - center))
    return _sigmoid(center_logit + (logit - center_logit) / temperature)


def _flag(value: object) -> float:
    return 1.0 if value else 0.0


def _clip_probability(value: object) -> float:
    try:
        p = float(value)
    except Exception:
        return float(GLOBAL_MEAN)
    if not math.isfinite(p):
        return float(GLOBAL_MEAN)
    if p < EPS:
        return float(EPS)
    if p > 1.0 - EPS:
        return float(1.0 - EPS)
    return float(p)


_load_artifacts()
